// ===== Izvēlne mobilajām ierīcēm =====
const izvelnesPoga = document.getElementById("izvelnesPoga");
const galvenaIzvelne = document.getElementById("galvenaIzvelne");

izvelnesPoga.addEventListener("click", function () {
    const irAtverta = galvenaIzvelne.classList.toggle("atverta");
    izvelnesPoga.setAttribute("aria-expanded", irAtverta);
});

// Pēc saites nospiešanas izvēlni aizver, lai tā neaizsegtu saturu
galvenaIzvelne.querySelectorAll("a").forEach(function (saite) {
    saite.addEventListener("click", function () {
        galvenaIzvelne.classList.remove("atverta");
        izvelnesPoga.setAttribute("aria-expanded", "false");
    });
});

// ===== Pavērsienu karuselis =====
const lente = document.getElementById("karuselisLente");
const slaidi = lente.querySelectorAll(".paversiena-slaids");
const atpakalPoga = document.getElementById("atpakalPoga");
const uzPriekshuPoga = document.getElementById("uzPriekshuPoga");
const apturetPoga = document.getElementById("apturetPoga");
const punktuKonteineris = document.getElementById("karuselisPunkti");
const slaidaNumurs = document.getElementById("karuselisNumurs");
const karuselisKaste = document.getElementById("karuselisKaste");

const MAINAS_LAIKS = 4000; // cik ilgi (ms) slaids paliek ekrānā
let esosaisSlaids = 0;
let taimeris = null;
let automatiskiMainas = true;

// Katram slaidam izveidojam savu punktu
slaidi.forEach(function (slaids, indekss) {
    const punkts = document.createElement("button");
    punkts.type = "button";
    punkts.className = "punkts";
    punkts.setAttribute("aria-label", "Slaids " + (indekss + 1));
    punkts.addEventListener("click", function () {
        raditSlaidu(indekss);
        atjaunotTaimeri();
    });
    punktuKonteineris.appendChild(punkts);
});

const punkti = punktuKonteineris.querySelectorAll(".punkts");

function raditSlaidu(indekss) {
    // Pēdējam slaidam seko pirmais un otrādi
    esosaisSlaids = (indekss + slaidi.length) % slaidi.length;
    lente.style.transform = "translateX(-" + esosaisSlaids * 100 + "%)";

    punkti.forEach(function (punkts, i) {
        punkts.classList.toggle("aktivs", i === esosaisSlaids);
    });
    slaidaNumurs.textContent = "Attēls " + (esosaisSlaids + 1) + " no " + slaidi.length;
}

function nakamaisSlaids() {
    raditSlaidu(esosaisSlaids + 1);
}

function iepriekspejaisSlaids() {
    raditSlaidu(esosaisSlaids - 1);
}

function sakumtTaimeri() {
    clearInterval(taimeris);
    taimeris = setInterval(nakamaisSlaids, MAINAS_LAIKS);
}

function apturetTaimeri() {
    clearInterval(taimeris);
    taimeris = null;
}

function atjaunotTaimeri() {
    if (automatiskiMainas) {
        sakumtTaimeri();
    }
}

function iestatitAtskanosanu(vertiba) {
    automatiskiMainas = vertiba;
    apturetPoga.textContent = automatiskiMainas ? "Apturēt" : "Atsākt";
    if (automatiskiMainas) {
        sakumtTaimeri();
    } else {
        apturetTaimeri();
    }
}

uzPriekshuPoga.addEventListener("click", function () {
    nakamaisSlaids();
    atjaunotTaimeri();
});

atpakalPoga.addEventListener("click", function () {
    iepriekspejaisSlaids();
    atjaunotTaimeri();
});

apturetPoga.addEventListener("click", function () {
    iestatitAtskanosanu(!automatiskiMainas);
});

// Kamēr kursors atrodas virs karuseļa, automātisko maiņu uz brīdi pauzējam
karuselisKaste.addEventListener("mouseenter", function () {
    if (automatiskiMainas) {
        apturetTaimeri();
    }
});

karuselisKaste.addEventListener("mouseleave", function () {
    if (automatiskiMainas) {
        sakumtTaimeri();
    }
});

// Pārslēgšana ar tastatūras bultiņām
document.addEventListener("keydown", function (notikums) {
    if (notikums.key === "ArrowRight") {
        nakamaisSlaids();
        atjaunotTaimeri();
    } else if (notikums.key === "ArrowLeft") {
        iepriekspejaisSlaids();
        atjaunotTaimeri();
    }
});

// Švīkšana pa skārienekrānu (telefoniem un planšetēm)
let skarsSakumaX = 0;

karuselisKaste.addEventListener("touchstart", function (notikums) {
    skarsSakumaX = notikums.changedTouches[0].clientX;
}, { passive: true });

karuselisKaste.addEventListener("touchend", function (notikums) {
    const starpiba = notikums.changedTouches[0].clientX - skarsSakumaX;
    if (Math.abs(starpiba) > 50) {
        if (starpiba < 0) {
            nakamaisSlaids();
        } else {
            iepriekspejaisSlaids();
        }
        atjaunotTaimeri();
    }
}, { passive: true });

// Palaižam karuseli
raditSlaidu(0);
sakumtTaimeri();
