# Virtuālā izstāde – tīmekļa vietnes izstrādes projekts

## 1. Projekta apraksts

Projekts ir izstrādāts prakses laikā, izmantojot HTML5, CSS3 un JavaScript.
Projekta mērķis ir izveidot interaktīvu un responsīvu tīmekļa vietni – virtuālu izstādi par izvēlēto tēmu.

**Izstādes tēma:** Videospēļu vēsture

**Izstādes nosaukums:** Pikseļu laikmets

## 2. Komandas dalībnieki

1. [Vārds, uzvārds]
2. [Vārds, uzvārds]
3. [Vārds, uzvārds]

## 3. GitHub repozitorijs

Projekta pirmkods un izstrādes vēsture ir pieejama GitHub repozitorijā:

GitHub Repository: [Ievietojiet saiti uz savu GitHub repozitoriju](https://github.com/lietotajs/repozitorijs)

## 4. Izmantotās tehnoloģijas

- **HTML5** – tīmekļa vietnes struktūras izveidei.
- **CSS3** – tīmekļa vietnes dizainam, Box Model, Flexbox/Grid un responsīvajam izkārtojumam.
- **JavaScript** – interaktīvu funkciju un attēlu karuseļa izveidei.
- **GitHub** – projekta failu versiju kontrolei un komandas sadarbībai.

## 5. Tīmekļa vietnes funkcionalitāte

Izstrādātajā tīmekļa vietnē ir:

- Galvene un navigācijas izvēlne (mobilajās ierīcēs – izkrītošā izvēlne).
- Hero sadaļa ar pogu uz izstādes saturu.
- Izstādes apraksts.
- Attēlu galerija (8 attēli) ar CSS Grid izkārtojumu.
- Interaktīvs attēlu karuselis (5 attēli).
- Manuāla (pogas, punkti, tastatūras bultiņas, švīkšana) un automātiska attēlu pārslēgšana.
- Automātiskās pārslēgšanas apturēšana un atsākšana.
- Responsīvs dizains dažādām ierīcēm (Media Queries).
- Lapas kājene ar informāciju par projekta autoriem.

## 6. Projekta palaišana

1. Lejupielādējiet projekta failus vai klonējiet GitHub repozitoriju.
2. Atveriet projekta mapi.
3. Atveriet failu `index.html` tīmekļa pārlūkprogrammā.
4. Pārbaudiet tīmekļa vietnes funkcionalitāti.

```bash
git clone https://github.com/lietotajs/repozitorijs.git
```

## 7. Projekta struktūra

```text
virtuala-izstade/
├── index.html
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
    ├── hero.svg
    ├── galerija-1.svg ... galerija-8.svg
    └── karuselis-1.svg ... karuselis-5.svg
```

## 8. Projekta izstrādes ieguldījums

Īss apraksts par katra komandas dalībnieka paveikto darbu:

- [Vārds, uzvārds]: [Aprakstiet paveikto darbu.]
- [Vārds, uzvārds]: [Aprakstiet paveikto darbu.]
- [Vārds, uzvārds]: [Aprakstiet paveikto darbu.]
