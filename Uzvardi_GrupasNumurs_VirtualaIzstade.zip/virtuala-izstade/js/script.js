// ===== Mobilā izvēlne =====
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", function () {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", isOpen);
});

mainNav.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
        mainNav.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
    });
});

// ===== Attēlu karuselis =====
const track = document.getElementById("carouselTrack");
const slides = track.querySelectorAll(".slide");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const playBtn = document.getElementById("playBtn");
const dotsBox = document.getElementById("carouselDots");
const counter = document.getElementById("carouselCounter");
const carouselBox = document.getElementById("carousel-box");

const INTERVAL = 4000;
let current = 0;
let timer = null;
let isPlaying = true;

// Punktu izveide katram slaidam
slides.forEach(function (slide, index) {
    const dot = document.createElement("button");
    dot.type = "button";
    dot.className = "dot";
    dot.setAttribute("aria-label", "Slaids " + (index + 1));
    dot.addEventListener("click", function () {
        showSlide(index);
        restartTimer();
    });
    dotsBox.appendChild(dot);
});

const dots = dotsBox.querySelectorAll(".dot");

function showSlide(index) {
    current = (index + slides.length) % slides.length;
    track.style.transform = "translateX(-" + current * 100 + "%)";

    dots.forEach(function (dot, i) {
        dot.classList.toggle("active", i === current);
    });
    counter.textContent = "Attēls " + (current + 1) + " no " + slides.length;
}

function nextSlide() {
    showSlide(current + 1);
}

function prevSlide() {
    showSlide(current - 1);
}

function startTimer() {
    clearInterval(timer);
    timer = setInterval(nextSlide, INTERVAL);
}

function stopTimer() {
    clearInterval(timer);
    timer = null;
}

function restartTimer() {
    if (isPlaying) {
        startTimer();
    }
}

function setPlaying(value) {
    isPlaying = value;
    playBtn.textContent = isPlaying ? "Apturēt" : "Atsākt";
    if (isPlaying) {
        startTimer();
    } else {
        stopTimer();
    }
}

nextBtn.addEventListener("click", function () {
    nextSlide();
    restartTimer();
});

prevBtn.addEventListener("click", function () {
    prevSlide();
    restartTimer();
});

playBtn.addEventListener("click", function () {
    setPlaying(!isPlaying);
});

// Pauze, kamēr peles kursors ir virs karuseļa (ja automātiskā ritināšana ir ieslēgta)
carouselBox.addEventListener("mouseenter", function () {
    if (isPlaying) {
        stopTimer();
    }
});

carouselBox.addEventListener("mouseleave", function () {
    if (isPlaying) {
        startTimer();
    }
});

// Navigācija ar tastatūras bultiņām
document.addEventListener("keydown", function (event) {
    if (event.key === "ArrowRight") {
        nextSlide();
        restartTimer();
    } else if (event.key === "ArrowLeft") {
        prevSlide();
        restartTimer();
    }
});

// Skārienekrāna švīkšana
let touchStartX = 0;

carouselBox.addEventListener("touchstart", function (event) {
    touchStartX = event.changedTouches[0].clientX;
}, { passive: true });

carouselBox.addEventListener("touchend", function (event) {
    const diff = event.changedTouches[0].clientX - touchStartX;
    if (Math.abs(diff) > 50) {
        if (diff < 0) {
            nextSlide();
        } else {
            prevSlide();
        }
        restartTimer();
    }
}, { passive: true });

// Starts
showSlide(0);
startTimer();
