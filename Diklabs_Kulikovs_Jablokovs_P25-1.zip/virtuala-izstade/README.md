# Virtuālā izstāde – tīmekļa vietnes izstrādes projekts

## 1. Projekta apraksts

Projekts ir izstrādāts prakses laikā, izmantojot HTML5, CSS3 un JavaScript.
Projekta mērķis ir izveidot interaktīvu un responsīvu tīmekļa vietni – virtuālu izstādi par izvēlēto tēmu.

**Izstādes tēma:** Videospēļu vēsture

**Izstādes nosaukums:** Pikseļu laikmets

## 2. Komandas dalībnieki

1. Artjoms Diklabs
2. Platons Kulikovs
3. Vladimirs Jablokovs

## 3. GitHub repozitorijs

Projekta pirmkods un izstrādes vēsture ir pieejama GitHub repozitorijā:

GitHub Repository: [https://github.com/Medadon/Prakse-16.11.2026](https://github.com/Medadon/Prakse-16.11.2026)

## 4. Izmantotās tehnoloģijas

- **HTML5** – tīmekļa vietnes struktūras izveidei.
- **CSS3** – tīmekļa vietnes dizainam, Box Model, Flexbox/Grid un responsīvajam izkārtojumam.
- **JavaScript** – interaktīvu funkciju un attēlu karuseļa izveidei.
- **GitHub** – projekta failu versiju kontrolei un komandas sadarbībai.

## 5. Tīmekļa vietnes funkcionalitāte

Izstrādātajā tīmekļa vietnē ir:

- Galvene un navigācijas izvēlne (mobilajās ierīcēs – izkrītošā izvēlne).
- Hero sadaļa ar pogu uz izstādes saturu.
- Izstādes apraksts.
- Attēlu galerija (8 attēli) ar CSS Grid izkārtojumu.
- Interaktīvs attēlu karuselis (5 attēli).
- Manuāla (pogas, punkti, tastatūras bultiņas, švīkšana) un automātiska attēlu pārslēgšana.
- Automātiskās pārslēgšanas apturēšana un atsākšana.
- Responsīvs dizains dažādām ierīcēm (Media Queries).
- Lapas kājene ar informāciju par projekta autoriem.

## 6. Projekta palaišana

1. Lejupielādējiet projekta failus vai klonējiet GitHub repozitoriju.
2. Atveriet projekta mapi.
3. Atveriet failu `index.html` tīmekļa pārlūkprogrammā.
4. Pārbaudiet tīmekļa vietnes funkcionalitāti.

```bash
git clone https://github.com/Medadon/Prakse-16.11.2026.git
```

## 7. Projekta struktūra

```text
virtuala-izstade/
├── index.html
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
    ├── hero.webp
    ├── galerija-*.jpg
    ├── karuselis-*.jpg
    ├── mario-2d-3d.jpg
    └── pong-ekrans.jpg
```

## 8. Projekta izstrādes ieguldījums

Īss apraksts par katra komandas dalībnieka paveikto darbu:

- Artjoms Diklabs: HTML struktūra, semantiskie elementi un navigācija.
- Platons Kulikovs: CSS dizains, Flexbox/Grid un responsīvais izkārtojums.
- Vladimirs Jablokovs: attēlu kolekcija un JavaScript karuselis.
